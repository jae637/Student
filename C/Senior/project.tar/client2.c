#include "protocol.h"

/* argv[1]은 수와 점 표기의 IP 주소 */
int main(int argc, char *argv[])
{
    int sockfd;
    struct sockaddr_in servAddr;
    char sendBuffer[BUFSIZE], recvBuffer[BUFSIZE];
    int recvLen, servLen;
	int data=1;		//입력할 데이터 량
	int i;
   	int windowsize=1;	//윈도우 사이즈
	int criticalvalue=8;	//임계값
	int count;		//
	int set;		//데이터 남는 양
	int recvnum;		//받는 값

    if(argc != 2) {
       fprintf(stderr, "Usage: %s IP_address\n", argv[0]);
       exit(1);
    }

    /* 소켓 생성 */
    if((sockfd=socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
       perror("sock failed");
       exit(1);
    }

    memset(&servAddr, 0, sizeof(servAddr));
    /* servAddr에 IP 주소와 포트 번호를 저장 */
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = inet_addr(argv[1]);
    servAddr.sin_port = htons(PORT);

    /* quit를 입력 받을 때까지 반복 */
    while(1) {
       printf("몇개의 데이터를 보내시겠습니까? : ");
	//scanf("%d",data);
	/*
	for(i=0;i<data;i++){
		for(j=0;j<windowsize;j++){
			i++;
			if ((rand()%100)<95)
			else
				i--;
			strcat(sendBuffer,itoa(i));
			sleep(100);
		}
	/*
       		/* sockfd 소켓을 통해 servAddr을 주소로 갖는 서버에게 데이터를 보냄 */
	/*
       		if(sendto(sockfd, sendBuffer, strlen(sendBuffer), 0, (struct sockaddr*)&servAddr, sizeof(servAddr)) != strlen(sendBuffer)) {
      			perror("sendto failed");
			exit(1);
		}
		if(windowsize<criticalvalue){
			windowsize=windowsize*2;
		}
		else{
			windowsize++;
		}
	}*/
	scanf("%d",set);
	while(set){
	//윈도우 사이즈만큼 데이터 보내기
		count = 0;
		for(i=0;i<windowsize;i++){
			data =1;
			//손실
			if((int)(rand()*100)>95){
				data =0;
				sendto(sockfd, &data, sizeof(int),0,(struct sockaddr*)&servAddr,sizeof(servAddr));
				continue;
			}
			//타임 아웃
			if((int)(rand()*100)>95){
				continue;
			}
			//정상 송신
			else
				sendto(sockfd, &data, sizeof(int),0,(struct sockaddr*)&servAddr,sizeof(servAddr));
			set--;
			count++;
			sleep(1);
		}
		//윈도우 사이즈 조절
		if(count==windowsize){
			if(windowsize<criticalvalue)
				windowsize=windowsize*2;
			else
				windowsize++;
		}
		else{
			windowsize=1;
		}
	}
       /* sockfd 소켓을 통해 servAddr을 주소로 갖는 서버에게 데이터를 보냄 */
/*
       if(sendto(sockfd, sendBuffer, strlen(sendBuffer), 0, (struct sockaddr*)&servAddr, sizeof(servAddr)) != strlen(sendBuffer)) {
          perror("sendto failed");
          exit(1);
       }
       servLen = sizeof(servLen);
*/

	/* sockfd 소켓으로 들어오는 데이터를 받아 recvBuffer에 저장 */
/*
       if((recvLen=recvfrom(sockfd, recvBuffer, BUFSIZE-1, 0, (struct sockaddr*)&servAddr, &servLen)) != strlen(sendBuffer)) {
          perror("recvfrom failed");
          exit(1);
       }
       recvBuffer[recvLen] = '\0';
*/
       /* 받은 데이터를 출력 */
       printf("Recevied: %s\n", recvBuffer);
    }
    close(sockfd);
    exit(1);
}
