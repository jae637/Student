int multnum(int a, int b)
{
        int sum;
        sum=a*b;
        return sum;
}