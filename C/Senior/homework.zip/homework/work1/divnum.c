int divnum(int a, int b){
        int sum;

        sum= a/b;

        return sum;
}
